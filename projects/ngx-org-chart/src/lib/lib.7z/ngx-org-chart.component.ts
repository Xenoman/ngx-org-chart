import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ngx-org-chart',
  template: `
    <p>
      ngx-org-chart works!
    </p>
  `,
  styles: [
  ]
})
export class NgxOrgChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
